package com.Grupo12.Login.entity;

public enum Rol{
    admin,
    user
}